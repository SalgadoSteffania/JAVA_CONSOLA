package matricula;

import java.util.Scanner;

public class Matricula {

	public static void main(String[] args) {
		Scanner lector=new Scanner(System.in);
		// Variables
				int NRecibo,nInscripcion,cantidad,frc;
				String Nombre,Apellido,carnet,Semestre,turno,Asign,grupo,aula,justf;
				int opcion,codAsig,crdts,retiro;
				int opcion2;
				do {
				//	 {
				System.out.println("Bienvenid@ a nuestro sistema, favor  ingrese la opcion de su preferencia");
				System.out.println("");
				System.out.println("Opcion 1: Ingresar al Programa  de matriculas");
				System.out.println("Opcion 2: Salir del programa");
				System.out.print("Opcion : ");
				opcion = lector.nextInt();
				if (opcion <= 0) {
						while (opcion <= 0) {
							System.out.println("Ha ingresado una opcion invalida");
							System.out.print("Opcion : ");
							opcion = lector.nextInt();
							while (opcion >= 3) {
								System.out.println("Usted ha ingresado una opcion invalida, favor ingrese una opcion valida");
								System.out.print("Opcion : ");
								opcion = lector.nextInt();
							}
						}
			
				}
				}while(opcion==2);	
				do {
				System.out.println("Hoja de Matricula del a�o 2021");
				System.out.println("N. De recibo: ");
				NRecibo=lector.nextInt();
				
				System.out.println("N. Inscripcion");
				nInscripcion=lector.nextInt();
				
				System.out.println("CARRERA: INGENIERIA DE SISTEMAS");
				
				System.out.println("Carnet: ");
				carnet=lector.next();
						
				System.out.println("Nombre: ");			
				Nombre=lector.next();
				System.out.println("Apellido: ");
				Apellido=lector.next();
				System.out.println("PLAN DE ESTUDIO: 2015");
				;
				System.out.println("Turno: ");
				turno=lector.next();
				
				System.out.println("Ingrese la cantidad de Asisgnaturas que desea Inscribir");
				cantidad=lector.nextInt();
				//No se permiten mas de 7 asig
				
				
					if(cantidad >7){
						while(cantidad >7){
					System.out.println("No puedes inscribir mas de 7 asignaturas");
					System.out.println("Ingrese la cantidad de Asisgnaturas que desea Inscribir");
					cantidad=lector.nextInt();
					
						}
					while (cantidad < 0) {
					System.out.println("No puedes ingresar numeros negativos");
					System.out.println("Ingrese la cantidad de Asisgnaturas que desea Inscribir");
					cantidad=lector.nextInt();
					
					}
				}
					/////////////////////////////////
					String[]codAsig1=new String[cantidad];
		 		System.out.println("Codigo de asignaturas");
		 		for(int i=0; i<codAsig1.length;i++)
		 		codAsig1[i]=lector.next();
		 		/////////////////////////////////////////////
		 		String[] Asignaturas=new String[cantidad];
		 		System.out.println("Ingrese las asignaturas");
					for(int i=0; i< Asignaturas.length;i++) {
						Asignaturas[i]=lector.next();
					}
		 		////////////////////////////////////////
		 		String[]grupo1=new String[cantidad];
					System.out.println("Grupo");
					for(int i=0;i<grupo1.length;i++) {
		 		grupo1[i]=lector.next();
					}
			///////////////////////////////////////////////////
					String[]aula1=new String[cantidad];
		 		System.out.println("Aula");
		 		for(int i=0;i<aula1.length;i++) {
		 		aula1[i]=lector.next();
		 		}
		 		//////////////////////////////////////////
		 		int[]crdts1=new int[cantidad];
		 		System.out.println("Creditos de Asignaturas");
		 		for(int i=0;i<crdts1.length;i++) {
		 		crdts1[i]=lector.nextInt();
		 		if(crdts1[i]>4) {
		 			while(crdts1[i]>4) {
		 				System.out.println("Los creditos no pueden ser mayor que 4");
		 				System.out.println("Creditos de Asignaturas");
				 		crdts1[i]=lector.nextInt();
		 			}
		 		}	
		 		}
		 		///////////////////////////////////////////////
		 		int[]frc1=new int[cantidad];
		 		System.out.println("Frecuencias de inscripciones de Asignatura");
		 		for(int i=0 ;i<frc1.length;i++) {
		 		frc1[i]=lector.nextInt();
		 		if(frc1[i]>3) {
		 			while(frc1[i]>3) {
		 				System.out.print("No puede tener mas de tres frecuencia");
		 				System.out.println("Frecuencias de inscripciones de Asignatura");
		 				frc1[i]=lector.nextInt();
		 			}
		 		}
		 	}
		 		////////////////////////////////////////////
		 		int[]retiro1=new int[cantidad];
		 		System.out.println("Retiro de Asignatura");
		 		for(int i=0;i<retiro1.length;i++) {
		 			retiro1[i]=lector.nextInt();
		 			if(retiro1[i]>0) {
		 				while(retiro1[i]>0) {
		 				System.out.println("Justifique");
		 				justf=lector.next();
		 				System.out.println("Retiro de Asignatura");
		 				retiro1[i]=lector.nextInt();
		 				}
		 			}
		 		}
		 		
				////////////////////////////////////////////////////////////////////////
		 		//System.out.println("    ");	
					
	 		////System.out.println();	
		 		System.out.println("");
					
				//int [][]asign=new int [5][6];
				//asign[0][0]=;
		 		
		 		System.out.println("Hoja de Matricula del a�o 2021");
		 		System.out.println("A�o academico 2021");
		 		System.out.println("-------------------------------------------------------");
		 		System.out.print("N.Recibo= "+NRecibo);
		 		System.out.print("                         ");
		 		System.out.println("N.Inscripcion= "+nInscripcion);
		 		System.out.println("-------------------------------------------------------");
		 		System.out.print("Nombres y Apellidos: "+Nombre);
		 		System.out.println(" "+Apellido);
		 		System.out.print("CARRERA: INGENIERIA DE SISTEMAS");
		 		System.out.print("  ");
		 		System.out.print("Carnet: "+carnet);
		 		System.out.print(" ");
		 		System.out.print("Turno: "+turno);
		 		System.out.println("      ");
		 		System.out.print("PLAN DE ESTUDIO: 2015            ");
				System.out.print("SEMESTRE: Primer Semestre 2021 ");
		 		System.out.println("      ");
		 		System.out.println("--------------------------------------------------------");
		 		
		 	
		 	System.out.print("  ");
		 	System.out.print("Cod.Asignatura");
		 	System.out.print("    ");
		 	System.out.print("Asignaturas");
		 	System.out.print("       ");
		 	System.out.print("Grupo");
		 	System.out.print("       ");
		 	System.out.print("Aula");
		 	System.out.print("       ");
		 	System.out.print("Creditos");
		 	System.out.print("         ");
		 	System.out.print("Frecuencia");
		 	System.out.print("      ");
		 	System.out.print("Retiro");
		 	System.out.println("       ");
					
		
       for(int i=0;i<codAsig1.length;i++)
       {System.out.println(Asignaturas[i]+"      "+grupo1[i]+"       "+aula1[i]+"       "+crdts1[i]+"      "+frc1[i]+"     "+retiro1[i]);
             System.out.println();
     		}
     					
				
      
			System.out.println("Desea volver a usar el programa de matricula?");
			System.out.println("si(1)");
			System.out.println("No(2)");
			opcion = lector.nextInt();
		}while(opcion<2 || opcion>1);

		
	}//cierre main
}//cierre de clase 
				//System.out.println();
				//System.out.println();
				//System.out.println();
				//System.out.println();
				//System.out.println();
				
	

				

				
				
				
				
			

	


