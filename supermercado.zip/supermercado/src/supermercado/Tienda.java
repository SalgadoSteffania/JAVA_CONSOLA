package supermercado;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Tienda {
	
 static Scanner lector=new Scanner(System.in);
 
 //////////////////////
 ////////////////////////
 
 public void MostrarInventario() {
	 
 String Inventario[]=new String[6];
  double precio[]=new double[6];
 // String codigo[]=new String[5];
  
 Inventario[0]="";
 precio[0]=0;
  
 Inventario[1]="Lavadora";
 precio[1]=5000;

 
 //System.out.println(Inventario[1]+"   "+precio[1]);
 
 Inventario[2]="Refrigeradora";
 precio[2]=15000;
 
 
 Inventario[3]="Telefono";
 precio[3]=12000;
 
 Inventario[4]="Pc";
 precio[4]=20000;
 
 
 Inventario[5]="Equipo de Sonido";
 precio[5]=8000; 
 
 
 
 for(int i=0;i<Inventario.length;i++) {
	 
	 System.out.println("Producto "+i+"  "+Inventario[i]+" \n "+"Precio  "+precio[i]+"\n");
        
    }
 
  
 }
 ////////////////////
 ////////////////////
 
/* 
 public void IngresarProducto() {
	 
	 System.out.println("Ingrese la cantidad de productos que desea agregar");
	 int p=lector.nextInt();
	  String Nuevo[]=new String[p];
	  
	  System.out.println("Ingrese e");
	  for(int i=0;i<Nuevo.length;i++) {
		  System.out.println("Ingrese el nombre del producto "+i);
		  Nuevo[i]=lector.next();
	  }
	  
	 
//	 System.out.println(Inventario[]+Nuevo[i]);
	 
	 
 }*/
 
 
 public void Facturar() {
	 
	 String Inventario[]=new String[5];
	 
	  
	  Inventario[0]="";
	
	  Inventario[1]="Lavadora";
	
	  Inventario[2]="Refrigeradora";
	 
	  Inventario[3]="Telefono";
	
	  Inventario[4]="Pc";
	 
	  Inventario[5]="Equipo de Sonido";
	  
	 
	 System.out.println("Cuantos productos va a facturar");
	 int cant=lector.nextInt();
	 int can[]=new int[cant];
	 //String producto[]=new String[cant];
	 
	 for(int i=0;i<can.length;i++) {
		 
		 System.out.println("Elija su producto insertando el numero que le corresponde "+"\n");

		 for(int i1=0;i1<Inventario.length;i1++) {
			 
			 System.out.println("Producto "+i1+"  "+Inventario[i1]+" \n ");
		        
		    }
		 
		 Inventario[i]=lector.next();
		 
	 }
	 
	 System.out.println("Desea imprimir su factura?");
	 System.out.println("1. Imprimir "+"\n"+"2. Cancelar compra");
	 int fac=lector.nextInt();
	
	 if(fac==1) {
		 System.out.println("Introduzca su nombre");
		 String nom=lector.next();
		 System.out.println("Introduzca su apellido ");
		 String Apell=lector.next();
		 System.out.println("");
		 System.out.println("-------------------------------------------------------------");
		 
		 
			System.out.println("____________Tienda de Electrodomesticos_____________"+" \n"+"___________________El Buen Pastor_________________/");
			System.out.println();
		int i=0;
		System.out.println("Cliente:  "+nom+"   "+Apell+"   "+"\n"+"\n"+"Cantidad "+" "+"Producto"+"   "+"Precio"+"\n"+cant+"         "+Inventario[cant]+"    ");
		
					
	 }else 
		 if(fac==2) {
		 System.out.println("Ha canselado su compra!");
	 }
       System.out.println("----------------------------------------");
	 
	 
	 
 }
 //////////////
 //////////////
 ///////////
 
 public static int busqueda() {

	 String Inventario[]=new String[5];
	 
	 Inventario[0]="";
		
	  Inventario[1]="Lavadora";
	
	  Inventario[2]="Refrigeradora";
	 
	  Inventario[3]="Telefono";
	
	  Inventario[4]="Pc";
	 
	  Inventario[5]="Equipo de Sonido";
	  

	 String Buscar;
	 
	 Scanner leer=new Scanner(System.in);
 	
 	System.out.println("Ingrese el nombre que desea buscar");
 	Buscar=leer.next();
 	

	 
	 int pos=Inventario.length+1;
	 
	 for(int i=0;i<Inventario.length;i++) {
		 
		 if(Inventario[i].equals(Buscar)) {
			 pos=i;
			 System.out.println(Buscar+" Fue encontrado en la posicion "+pos);
		 }
		 
		 
	 }
	return pos;
	
	
	
}
 
 /////////////////
 ////////////////
	public static void main(String[] args) {
			int opc=0;
			String codigo;
			String Producto = null;
			int Cantidad;
			double Precio;
			String Compra;
			boolean continuar;
			
			Object e = null;
			int opcion = 0;
			do {	
			
			do {
				
			 try {
				continuar=false;
				
				System.out.println("__________Bienvenidos a Tienda de Electrodomesticos____________"+" \n"+"___________________El Buen Pastor_________________");
			System.out.println();
						System.out.println("1. Mostar Inventario");
						System.out.println("2. Facturar");
						//System.out.println("3.Buscar productos");
						//System.out.println("4.");
						 opc=lector.nextInt();
			 }catch (Exception a) {
					System.out.println("Error!, no puede ingresar letras ni simbolos");
					lector.next();
			continuar=true;
				}
				}while(continuar);
						 switch(opc) {
						 
						 case 1: 
						  Tienda I=new Tienda();
						  I.MostrarInventario();
							break;
							
						 case 2:
							 Tienda I1=new Tienda();
							 I1.Facturar();
							 break;
							 
						 case 3:
							 Tienda I2=new Tienda();
							 I2.busqueda();
							break;
						 }
						 
						 
					
					//////////////////////////////////////	 //////////////////////
					//////////////////////////////////////////////////////////////	
						 
			
	//////////
			//////////////////
			 boolean seg;
			 
	do {
	 try {
		 seg=false;
						 Scanner lector=new Scanner(System.in);
				
					/*		System.out.println();
							System.out.println(); */
						System.out.println("Opcion 1: Continuar con el programa");
						System.out.println("Opcion 2: Salir del programa");
						System.out.print("Opcion : ");
						opcion = lector.nextInt();
						System.out.println("\n");
						if (opcion <= 0) {
								while (opcion<= 0) {
									System.out.println("Ha ingresado una opcion invalida");
									System.out.print("Opcion : ");
									opcion = lector.nextInt();
									while (opcion >= 3) {
										System.out.println("Usted ha ingresado una opcion invalida, favor ingrese una opcion valida");
										System.out.print("Opcion : ");
										opcion = lector.nextInt();
									}
								}

						}
						
						if(opcion==2) {
							System.out.println("Gracias por utilizar el programa");
							System.out.println();
						}
								 
	 }catch (Exception a) {
			System.out.println("Error, no puede ingresar letras ni simbolos");
		  System.out.println("\n");
	  seg= true;
		}
	}while(seg);		
						
						 
			}while(opcion==1);
			
			
			
			 
		}//// Main


}////////Clase
