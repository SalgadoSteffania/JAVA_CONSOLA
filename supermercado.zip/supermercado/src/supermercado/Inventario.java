package supermercado;

import java.util.Scanner;

public class Inventario {

	
	
	private static final String Buscar = null;
	
	public static void main(String[] args) {
		int t;
		String p;
		double precio;

		Scanner lector=new Scanner (System.in);
	
		
		System.out.println("Ingrese la cantidad de productos a ingresar a su Almacen: ");
		t=lector.nextInt();
	
		String Inventario[]=new String[t];
		double Precio[]=new double[t];
		
		
		for(int i=0;i<Inventario.length;i++) {
			
			System.out.println("Ingrese el nombre de los productos: ");
			Inventario[i]=lector.next();
			System.out.println("Ingrese el precio por unidad");
			Precio[i]=lector.nextDouble();
			
		}
			
		 
		MostrarInventario(Inventario,Precio);
	    Busqueda(Inventario,Buscar);
		
		
		
	}//Main
	
	
	public static void MostrarInventario(String Inventario[],double Precio[]) {
		
		System.out.println("---------Inventario--------------");
		
		for(int i=0;i<Inventario.length;i++) {
		
		System.out.println("Productos "+"\t"+Inventario[i]+"Precios :"+Precio[i]);
		
		}
		
	}	
		
		  public static int Busqueda(String Inventario[],String Buscar) {
			  
			 
		    	Scanner leer=new Scanner(System.in);
		    	
		    	System.out.println("Ingrese el nombre que desea buscar");
		    	Buscar=leer.next();
		    	
		    	int pos=Inventario.length;
		    	
		    	for(int i=0;i<Inventario.length;i++) {
		    		
		    		if(Inventario[i].equals(Buscar)) {
		    			pos=i;
		    			System.out.println("El producto "+Buscar+" se encontro en la posicion "+pos);
		    		}
		    		 
		    
		    	}
				return pos;
		    	

		
	}//Mostrar Inventario
	
	
}
	
