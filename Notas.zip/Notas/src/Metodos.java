

import java.util.InputMismatchException;
import java.util.Scanner;

public class Metodos {

	static boolean Continuar, X;
	static int Opcion, Nota, Respuesta, Opci, Opc, Opci2, Au;
	static double Auxiliar;
	static double[] NotaFinal = new double[34];
	static double[] NotaPrimera = new double[34];
	static double[] ExPrim = new double[34];
	static double[] ExSegun = new double[34];
	static int N[]= new int [34];
	
	static Metodos obj = new Metodos();
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		
	String Carrera = "Ingenieria de Sistemas", Curso = "Introduccion a la Programacion", PLectivo = "Primer Semestre 2021", Modalidad = "Regular";
	String CC = "30849", Grupo = "1M1-IS", CA = "81004", CPA = "1004", CE ="33 ";
	String PrimerS = "35.00", SegundoS = "35.00", Sistem = "15.00", Proyec = "0.00";
	int Nu = 0, MEfeciva, NDesertos = 0, CantApro, PorAproba, CantRepro, PorRepro;
	int MatInicial = 33;
	int Desert = 0, Aprob = 0, Repr = 0, Porc, Nota = 0;
	double Mayor = 0;
	double Menor = 100;
	int Cont = 1, Opcion = 0, Opcion1 = 0;
	int Notas []= new int [34];
	double[] PrimerP = new double[34];
	double[] SegundoP = new double[34];
	double[] Sist = new double[34];
	double[] Proyecto = new double[34];
	String[] Deserto = new String[34];
	String [] aproba = new String [34];
	int N[]= new int [34];
	
		N[0] = 0;
		N[1] = 1;
		N[2] = 2;
		N[3] = 3;
		N[4] = 4;
		N[5] = 5;
		N[6] = 6;
		N[7] = 7;
		N[8] = 8;
		N[9] = 9;
		N[10] = 10;
		N[11] = 11;
		N[12] = 12;
		N[13] = 13;
		N[14] = 14;
		N[15] = 15;
		N[16] = 16;       
		N[17] = 17;
		N[18] = 18;
		N[19] = 19;
		N[20] = 20;
		N[21] = 21;
		N[22] = 22;
		N[23] = 23;
		N[24] = 24;
		N[25] = 25;
		N[26] = 26;
		N[27] = 27;
		N[28] = 28;
		N[29] = 29;
		N[30] = 30;
		N[31] = 31;
		N[32] = 32;
		N[33] = 33;
	
	String NombresApellidosN []= new String[34];
		NombresApellidosN [0] = "";
		NombresApellidosN [1] = "AGUILAR PALACIO OBETH ANTONIO " + " con N� Carnet 2021-1009U";;
		NombresApellidosN [2] = "AGUIRRE REYES KENNET EVENOR " + " con N� Carnet 2021-0947U";
		NombresApellidosN [3] = "BARBERENA SOMARRIBA MARVIN GABRIEL " + " con N� Carnet 2021-0835U";
		NombresApellidosN [4] = "CANALES LAYNES KEVIN FRANCISCO " + " con N� Carnet 2021-0921U";
		NombresApellidosN [5] = "CHAVEZ ESQUIVEL ARTURO LENIN " + " con N� Carnet 2021-0912U";
		NombresApellidosN [6] = "CHAVEZ VANEGAS SALVADOR VLADIMIR " + " con N� Carnet 2021-0904U";
		NombresApellidosN [7] = "D�AZ TELLEZ WALTER DAVID " + " con N� Carnet 2021-0934U";
		NombresApellidosN [8] = "ESCORCIA ALVARADO DAYANA PAOLA " + " con N� Carnet 2014-0156U";
		NombresApellidosN [9] = "ESTRADA PARRALES JENNIFER GABRIELA " + " con N� Carnet 2021-0994U";
		NombresApellidosN [10] = "FLORES DIAZ JOSU� OMAR " + " con N� Carnet 2021-1037U";
		NombresApellidosN [11] = "FUERTES FLORES MARGIE EMILIA " + " con N� Carnet 2021-0955U";
		NombresApellidosN [12] = "GARCIA ESPINOZA ABDIEL ENMANUEL " + " con N� Carnet 2021-1102U";
		NombresApellidosN [13] = "GOMEZ DAVILA ROGER ANDRES " + " con N� Carnet 2021-0857U";
		NombresApellidosN [14] = "JIMENEZ JIMENEZ MAYKELING GUADALUPE " + " con N� Carnet 2021-0876U";
		NombresApellidosN [15] = "L�PEZ MOLINA ISMAEL ANTONIO " + " con N� Carnet 2021-1089U";
		NombresApellidosN [16]= "L�PEZ RUIZ EMANUEL ALEXANDER " + " con N� Carnet 2018-1048U";
		NombresApellidosN [17] = "LUMBI ARGE�AL ENMANUEL RAMCES " +  " con N� Carnet 2021-1056U";
		NombresApellidosN [18] = "MADR�Z MERCADO ALEX IVAN " + " con N� Carnet 2021-1097U";
		NombresApellidosN [19] = "MENESES RIVAS ELVIS JOSU� " + " con N� Carnet 2021-1109U";
		NombresApellidosN [20] = "NU�ES SEDILES MOIS�S DAVID "  + " con N� Carnet 2021-0986U";
		NombresApellidosN [21] = "OPORTA CASTILLO JORGE LUIS " + " con N� Carnet 2020-0912U";
		NombresApellidosN [22] = "RIVAS D�VILA DOUGLAS BENJAM�M " + " con N� Carnet 2021-0868U";
		NombresApellidosN[23] = "ROJAS CORRALES DIERISH ANTONIO " + " con N� Carnet 2021-0853U";
		NombresApellidosN [24] = "ROMERO GONZ�LEZ MANUEL BENOIT " + " con N� Carnet 2021-1288U";
		NombresApellidosN [25] = "ROSTRAN REYES ERLING ERNESTO " +  " con N� Carnet 2021-1075U";
		NombresApellidosN [26] = "RUIZ RAM�REZ ROBERTO DANIEL " + " con N� Carnet 2021-1003U";
		NombresApellidosN [27] = "RUIZ RUIZ OMAR JOS� " + " con N� Carnet 2021-0959U";
		NombresApellidosN [28] = "SAAVEDRA TORU�O SOLANGE GUADALUPE " + " con N� Carnet 2021-1049U";
		NombresApellidosN [29] = "SALGADO GAGO STEFFANIA MERCEDES " + " con N� Carnet 2021-0861U";
		NombresApellidosN [30] = "SANDOVAL R�OS ZIEGFREED GABRIEL " + " con N� Carnet 2021-0891U";
		NombresApellidosN [31] = "SILVA CRUZ SAMANTHA NICOLL " + " con N� Carnet 2021-0882U";
		NombresApellidosN [32] = "SOMOZA TELLES FRANCELA JULIETH " + " con N� Carnet 2021-0850U";
		NombresApellidosN [33] = "TORRES CALVO SILVANA ISABEL " + " con N� Carnet 2021-0978U";
	
do {
	do {
		try {
			Continuar = false;
		System.out.println("Bienvenido al Programa de Notas");
		System.out.println("Ingrese la opcion que desee");
		System.out.println("");
		System.out.println("Opcion 1: Comenzar el Programa");
		System.out.println("Opcion 2: Salir del Programa");
		System.out.print("Opcion: ");
		Opcion = sc.nextInt();
		
while(Opcion <= 0 || Opcion >= 3) {
			System.out.println("Por favor, ingrese una opcion valida");
			System.out.print("Opcion: ");
			Opcion = sc.nextInt();
}
	} catch (InputMismatchException e) {
            System.out.println("Por favor, ingrese solo numeros enteros");
            	  sc.next();
            	  System.out.println();
            	  Continuar = true;

switch (Opcion) {
	case 1:
		do {
			try {
		 		System.out.println("Bienvenido, por favor ingrese las siguentes notas");
				System.out.println(" ");
				
for(Nu=1; Nu < NombresApellidosN.length; Nu++) {
				System.out.println();
				System.out.println("Ingrese la nota del estudiante " + NombresApellidosN[Nu]);
				System.out.println(" ");
				System.out.println("Nota del Primer Parcial");
				System.out.print("Nota: ");
				
				PrimerP[Nu] =  sc.nextInt();
	while (PrimerP[Nu]> 35 || PrimerP[Nu]<= 0) {
				System.out.println("Por favor, ingrese un dato valida");
				System.out.print("Nota: ");
				PrimerP[Nu] =  sc.nextInt();
	}
}
			} catch (InputMismatchException e1) {
	            System.out.println("Por favor, ingrese solo numeros enteros");
	            	  sc.next();
	            	  System.out.println();
	            	  Continuar = true;
			}
			} while (Continuar);

	do {
		try {
				System.out.println("Nota del Segundo Parcial");
				System.out.print("Nota: ");
				SegundoP[Nu]= sc.nextInt();
				
	while (SegundoP[Nu]> 35 || SegundoP[Nu]<= 0) {
				System.out.println("Por favor, ingrese un dato valida");
				System.out.print("Nota: ");
				SegundoP[Nu] =  sc.nextInt();
}
	} catch (InputMismatchException e1) {
        System.out.println("Por favor, ingrese solo numeros enteros");
        	  sc.next();
        	  System.out.println();
        	  Continuar = true;
	}
	} while (Continuar);
	
	do {
		try {
				System.out.println();
				System.out.println("Nota de los Sistem�ticos");
				System.out.print("Nota: ");
				Sist[Nu]= sc.nextInt();
				
	while (Sist[Nu]> 35 || Sist[Nu]<= 0) {
				System.out.println("Por favor, ingrese un dato valida");
				System.out.print("Nota: ");
				Sist[Nu] =  sc.nextInt();
}
	} catch (InputMismatchException e1) {
        System.out.println("Por favor, ingrese solo numeros enteros");
        	  sc.next();
        	  System.out.println();
        	  Continuar = true;
	}
	} while (Continuar);
				NotaFinal[Nu] = PrimerP[Nu] + SegundoP[Nu] + Sist[Nu];
				System.out.println(" ");
	if (NotaFinal[Nu] >= 60) {
				Aprob++;
				aproba[Nu] = "Si";
}
	
	if (NotaFinal[Nu] < 60) {
		do {
			try {
			System.out.println();
			System.out.println("Nota del Primera Examen de Convocatoria");
			System.out.print("Nota: ");
			ExPrim[Nu] = sc.nextInt();
			
	while (ExPrim[Nu]> 70 || ExPrim[Nu]<= 0) {
			System.out.println("Por favor, ingrese un dato valida");
			System.out.print("Nota: ");
			PrimerP[Nu] =  sc.nextInt();
}
	} catch (InputMismatchException e1) {
		     System.out.println("Por favor, ingrese solo numeros enteros");
		      sc.next();
		       System.out.println();
		        Continuar = true;
	}
} while (Continuar);
			NotaPrimera[Nu] = ExPrim[Nu] + Sist[Nu];
	if (NotaPrimera[Nu] >= 60) {
			Aprob++;
			aproba[Nu] = "Si";
			NotaPrimera[Nu] = Notas[Nu];
			
}else {
	do {
		try {
			System.out.println();
			System.out.println("Nota del Segundo Examen de Convocatoria");
			System.out.print("Nota: ");
			ExSegun[Nu]= sc.nextInt();
			
	while (ExPrim[Nu]> 100 || ExPrim[Nu]<= 0) {
			System.out.println("Por favor, ingrese un dato valida");
			System.out.print("Nota: ");
			PrimerP[Nu]=  sc.nextInt();
	}
}catch (InputMismatchException e1) {
    System.out.println("Por favor, ingrese solo numeros enteros");
	  sc.next();
	  System.out.println();
	  Continuar = true;
}
	} while (Continuar);
}

	if (ExSegun[Nu] >= 60) {
			Aprob++;
			aproba[Nu] = "Si";
			ExSegun[Nu] = Notas[Nu];
}else {
			Repr++;
	}
	
			System.out.println("�El Estudiante deserto?");
			Deserto[Nu] = sc.next();
	if (Deserto[Nu]=="Si") {
			Desert++;
			Deserto[Nu]= "Si";
	}
}
	do {
		try {
			System.out.println("�Desea continuar?");
			System.out.println("Opci�n 1: Si");
			System.out.println("Opci�n 2: No");
			System.out.print("Opci�n: ");
			System.out.println("");
			Opcion1= sc.nextInt(); 
			
	while(Opcion <= 0 || Opcion >= 3) {
				System.out.println("Por favor, ingrese una opcion valida");
				System.out.print("Opcion: ");
				Opcion = sc.nextInt();
	}
} catch (InputMismatchException e1) {
	            System.out.println("Por favor, ingrese solo numeros enteros");
	            	  sc.next();
	            	  System.out.println();
	            	  Continuar = true;
}
	}while (Continuar);
	
	if (Nu == NombresApellidosN.length || Opcion1!=1) {
		int A=1;
	while (A<= Nu) {
			System.out.println("No." + "\t"+ "\t" + "Apellidos, Nombres y Carnet del Estudiante" + "\t" + "\t" + "\t" +"1Parcial" + "\t" + "2Parcial" + "\t" + "Sistematico" + "\t" + "Proyecto" + "\t" + "Nota Final" + "\t" + "Examen de la primera Convo" + "\t" + "  " + "Nota Final de la primera Convo" + "\t" + "\t" + "SegundaConvo" + "\t" + "\t" + "  " + "�Aprob�?" + "\t" + "\t" + "�Deserci�n?");
			System.out.print(N[A] + "\t"  + "\t"+ NombresApellidosN[A] + "\t" + "\t" + PrimerP[A] + "\t" + SegundoP[A] + "\t" + Sist[A] + "\t" + Proyecto[A] + "\t" + NotaFinal[A] + "\t" + "\t" + ExPrim[A] + "\t" + "\t" + NotaPrimera[A] + "\t" + "\t" + ExSegun[A] + "\t" + "\t" + "      " + aproba[A] + "\t" + "\t" + Deserto[A]);
			System.out.println("");
			A++;
}
	
for(int i= 0; i < NombresApellidosN.length; i ++) {
	if (NotaFinal[i] > Mayor) {
			Mayor = NotaFinal[i];
	}
}

for(int i= 0; i < NombresApellidosN.length; i ++) {
	if (NotaFinal[i] < Menor) {
			Menor = NotaFinal[i];
	}
}

			MEfeciva= MatInicial - NDesertos;
			NDesertos = Desert;
			CantApro= Aprob;
			PorAproba= CantApro * 100 / N[Nu];	
			CantRepro= Repr;
			PorRepro = CantRepro * 100 / N[Nu];
			
	int h=1;
		while (Cont < N[A]) {
			Nota += NotaFinal[h];
			Cont++;
			h++;
}
		
	float Promedio= (Nota/ Cont)*2;
							
			System.out.println("Carrera: " + "\t" + Carrera + "\t" + "\t" + "Curso: " + "\t" + Curso + "\n" + "Per�odo: " + "\t" + PLectivo + "\t" + "\t" + "Modalidad: " + "\t" + Modalidad + "\n" + "C�digo del Curso: " + "\t" + CC + "\t" + "\t" + "\t" + "Grupo: " + "\t" + Grupo + "\n" + "C�digo de la Asignatura: " + "\t" + CA + "\t" + "\t" + "C�digo de Programa de Asignatura: " + "\t" + CPA + "\n" + "Cantidad de Estudiantes: " + "\t" + CE + "\t" + "\t" + "Primer Parcial: " + "\t" + PrimerS + "\n" + "Segundo Parcial: " + "\t" + "\t" + SegundoS + "\t" + "\t" + "Sistem�ticos: " + "\t" + Sistem + "\n" + "Proyecto de Curso: " + "\t" + Proyecto);
			System.out.println("Matr�cula Inicial" + "\t" + "Matr�cula Efectiva" + "\t" + "N�mero de Deserciones" + "\t" + "Cantidad de Aprobados" + "\t" + "% de Aprobados" + "\t" + "Cantidad de Reprobados" + "\t" + "\t" + "% de Reprobados" + "\t" + "\t" + "Nota M�nima" + "\t" + "Nota M�xima" + "\t" + "Promedio de Notas");
			System.out.println(MatInicial + "\t" + "\t" + "\t" + MEfeciva + "\t" + "\t" + "\t" + NDesertos + "\t" + "\t" +  "\t" + CantApro + "\t" + "\t" + "\t" + PorAproba + "\t" + "\t" + "\t" + CantRepro + "\t" + "\t" + "\t" + PorRepro + "\t" + "\t" + "\t" + Menor + "\t" + "\t" + "\t" + Mayor + "\t" + "\t" + "\t" + Promedio);
	}	
}

	do {
		try {
			System.out.println("�Desea ordenar las notas?");
			System.out.println("Opcion 1: Si");
			System.out.println("Opcion 2: No");
			System.out.print("Opcion: ");
			Respuesta = sc.nextInt();

	while(Respuesta <= 0 || Respuesta >= 3) {
			System.out.println("Por favor, ingrese una opcion valida");
			System.out.print("Opcion: ");
			Respuesta = sc.nextInt();
	}
} catch (InputMismatchException e1) {
			System.out.println("Por favor, ingrese solo numeros enteros");
			sc.next();
			System.out.println();
			Continuar = true;
	}
} while (Continuar);

switch(Respuesta) {
	case 1:
		do {
			try {
			System.out.println("�Que notas desea ordenar?");
			System.out.println("Opcion 1: Notas Finales");
			System.out.println("Opcion 2: Notas de la Primera Convocatoria");
			System.out.println("Opcion 3: Notas de la Segunda Convocatoria ");
			Opci2 = sc.nextInt();
	
while(Opci2 <= 0 || Opci2 >= 4) {
			System.out.println("Por favor, ingrese una opcion valida");
			System.out.print("Opcion: ");
			Opci2 = sc.nextInt();
	}
} catch (InputMismatchException e1) {
            System.out.println("Por favor, ingrese solo numeros enteros");
          	 sc.next();
             System.out.println();
             Continuar = true;
	}
} while (Continuar);
	
switch(Opci2) {
	case 1:
			obj.ordenarNotaFinal();
		break;
		
	case 2:
			obj.ordenarNotaPConv();
		break;
		
	case 3:
			obj.ordenarNotaSConv();
		break;
}
	
	case 2:
			System.out.println("Esperamos que le haya sido util el programa, que tenga buen dia");	
	break;
}

	do {
		try {
			System.out.println("�Desea hacer una busqueda de notas?");
			System.out.println("Opci�n 1: Si");
			System.out.println("Opci�n 2: No");
			System.out.print("Opci�n: ");
			Opc = sc.nextInt(); 
while(Opc <= 0 || Opc >= 4) {
			System.out.println("Por favor, ingrese una opcion valida");
			System.out.print("Opcion: ");
			Opc = sc.nextInt();
}
	} catch (InputMismatchException ex) {
        	System.out.println("Por favor, ingrese solo numeros enteros");
        	sc.next();
        	System.out.println();
        	Continuar = true;
	}
} while (Continuar);

switch(Opc) {
	case 1:
		do {
			try {
				System.out.println("�Que notas desea buscar?");
				System.out.println("Opcion 1: Notas Finales");
				System.out.println("Opcion 2: Notas de la Primera Convocatoria");
				System.out.println("Opcion 3: Notas de la Segunda Convocatoria ");
				Opci2 = sc.nextInt();
	
while(Opci2 <= 0 || Opci2 >= 4) {
			System.out.println("Por favor, ingrese una opcion valida");
			System.out.print("Opcion: ");
			Opci2 = sc.nextInt();
	}
} catch (InputMismatchException e1) {
            System.out.println("Por favor, ingrese solo numeros enteros");
            sc.next();
            System.out.println();
             Continuar = true;
	}
} while (Continuar);
	
switch(Opci2) {
	case 1:
			obj.buscarNotaFinal(Nota);
	break;
		
	case 2:
			obj.buscarPConvo(Nota);
	break;
		
	case 3:
			obj.buscarSConvo(Nota);
	break;
	}
	
case 2:
		System.out.println("Esperamos que le haya sido util el programa, que tenga buen dia");	
	break;
}

		obj.ordenar();
	if(Opcion != 1) {      
	}
}
		System.out.println("Esperamos que le haya sido util el programa, que tenga buen dia");
	}while(Continuar);
	}while (Opcion==1);
}
public static void ordenarNotaFinal() {
for (int i =0 ; i < 32 ; i++) {
	for(int l=0 ; l < 32; l++) {
		if (NotaFinal[l]> NotaFinal[l+1]) {
			Auxiliar = NotaFinal[l];
			NotaFinal[l]=NotaFinal[l+1];
			NotaFinal[l+1] = Auxiliar;
		}
	}
}

do {
	try {
		System.out.println("�Como lo desea ordenar:");
		System.out.println("Opcion 1: Ascendente");
		System.out.println("Opcion 2: Descendente");
int opc = sc.nextInt();

while(opc <= 0 || opc >= 3) {
		System.out.println("Por favor, ingrese una opcion valida");
		System.out.print("Opcion: ");
		opc = sc.nextInt();
}
	} catch (InputMismatchException e1) {
        System.out.println("Por favor, ingrese solo numeros enteros");
        sc.next();
        System.out.println();
        Continuar = true;
	}
} while (Continuar);


if (Opc ==1 ) {
		System.out.println("Ordenada de forma ascendente \n ");
		System.out.println("N�.  Nota Final \n");
for (int i = 0 ; i<NotaFinal.length ; i++) {
		System.out.println((i+1) + ". \t"+NotaFinal[i]);
}
	
}if (Opc == 2) {
		System.out.println("Ordenada de forma descendente \n ");
		System.out.println("N�.  Nota Final \n");
for (int i = NotaFinal.length, n=1 ; i>=0 ; i--, n++) {
		System.out.println((n) + ". \t"+NotaFinal[i]);
	}
}
}

public static void ordenarNotaPConv() {
for (int i =0 ; i < 32 ; i++) {
	for(int a=0 ; a < 32; a++) {
		if (NotaPrimera[a]> NotaPrimera[a+1]) {
			Auxiliar = NotaPrimera[a];
			NotaPrimera[a]=NotaPrimera[a+1];
			NotaPrimera[a+1] = Auxiliar;
		}
	}
}

do {
	try {
System.out.println("�Como desea ordenar?");
System.out.println("Opcion 1: Ascendente");
System.out.println("Opcion 2: Descendente");
int opc = sc.nextInt();

while(opc <= 0 || opc >= 3) {
	System.out.println("Por favor, ingrese una opcion valida");
	System.out.print("Opcion: ");
	opc = sc.nextInt();
}
} catch (InputMismatchException e1) {
System.out.println("Por favor, ingrese solo numeros enteros");
	  sc.next();
	  System.out.println();
	  Continuar = true;
}
} while (Continuar);

if (Opc ==1 ) {
	System.out.println("Ordenada de forma ascendente \n ");
	System.out.println("No.  Nota Final Iconv \n");
	for (int i = 0 ; i<NotaPrimera.length ; i++) {
		System.out.println((i+1) + ". \t"+NotaPrimera[i]);
	}
}if (Opc == 2) {
	System.out.println("Ordenada de forma descendente \n ");
	System.out.println("No.  Nota Final Iconv \n");
	for (int i = NotaPrimera.length, j=1 ; i>=0 ; i--, j++) {
		System.out.println((j) + ". \t"+NotaPrimera[i]);
		}
	}
}

public static void ordenarNotaSConv() {
for (int i =0 ; i < 32 ; i++) {
	for(int j=0 ; j < 32; j++) {
		if (ExPrim[j]> ExPrim[j+1]) {
			Auxiliar = ExPrim[j];
			ExPrim[j]=ExPrim[j+1];
			ExPrim[j+1] = Auxiliar;
		}
	}
}

do {
	try {
		System.out.println("�Como desea ordenar?");
		System.out.println("Opcion 1: Ascendente");
		System.out.println("Opcion 2: Descendente");
int opc = sc.nextInt();

while(opc <= 0 || opc >= 3) {
		System.out.println("Por favor, ingrese una opcion valida");
		System.out.print("Opcion: ");
		opc = sc.nextInt();
	}
} catch (InputMismatchException e1) {
		System.out.println("Por favor, ingrese solo numeros enteros");
		sc.next();
		System.out.println();
		Continuar = true;
	}
} while (Continuar);
	
if (Opc ==1 ) {
		System.out.println("Ordenada de forma ascendente \n ");
		System.out.println("No.  Nota IIconv \n");
for (int i = 0 ; i<ExSegun.length ; i++) {
		System.out.println((i+1) + ". \t"+ExSegun[i]);
	}
}if (Opc == 2) {
		System.out.println("Ordenada de forma descendente \n ");
		System.out.println("No.  Nota IIconv \n");
for (int i = ExSegun.length, j=1 ; i>=0 ; i--, j++) {
		System.out.println((j) + ". \t"+ExSegun[i]);
		}
	}
}

public static void buscarNotaFinal(double Nota) {
	do {
		try {
			System.out.println("�Que nota desea buscar?");
			Nota = sc.nextDouble();
while(Nota <= 0 || Nota >= 100) {
			System.out.println("Por favor, ingrese una opcion valida");
			System.out.print("Opcion: ");
			Nota = sc.nextInt();
}
} catch (InputMismatchException e1) {
		System.out.println("Por favor, ingrese solo numeros enteros");
		sc.next();
		System.out.println();
		Continuar = true;
	}
} while (Continuar);
		Au=0;
while(Au<33 && X == false) {
	if (NotaFinal[Au]== Nota) {
		X = true;
	}
	Au++;
}
		System.out.println("No."+N[Au]+" Nota:"+ NotaFinal[Au]);
}

public static void buscarSConvo(double Nota) {
	do {
		try {
			System.out.println("�Que nota desea buscar?");
			Nota = sc.nextDouble();
while(Nota <= 0 || Nota >= 100) {
			System.out.println("Por favor, ingrese una opcion valida");
			System.out.print("Opcion: ");
			Nota = sc.nextInt();
	}
} catch (InputMismatchException e1) {
			System.out.println("Por favor, ingrese solo numeros enteros");
			sc.next();
			System.out.println();
			Continuar = true;
	}
} while (Continuar);
Au=0;
while(Au<33 && X == false) {
	if (NotaPrimera[Au]== Nota) {
		X = true;
	}
	Au++;
}
		System.out.println("No."+N[Au]+" Nota:"+ NotaPrimera[Au]);
}

public static void buscarPConvo(double Nota) {
	do {
		try {
			System.out.println("�Que nota desea buscar?");
			Nota = sc.nextDouble();
while(Nota <= 0 || Nota >= 100) {
			System.out.println("Por favor, ingrese una opcion valida");
			System.out.print("Opcion: ");
			Nota = sc.nextInt();
	}
} catch (InputMismatchException e1) {
			System.out.println("Por favor, ingrese solo numeros enteros");
			sc.next();
			System.out.println();
			Continuar = true;
	}
} while (Continuar);
		Au=0;
while(Au<33 && X == false) {
	if (ExSegun[Au]== Nota) {
		X = true;
	}
	Au++;
	}
			System.out.println("No."+N[Au]+" Nota:"+ ExSegun[Au]);
}

public static void ordenar() {
int Reprobado = 0, Regular = 0, Bueno = 0, MuyBueno = 0, Excelente = 0;
for (int i = 1 ; i< NotaFinal.length ; i++) {
	if (NotaFinal[i]<=59) {
		Reprobado++;
		System.out.print("=");
		if(i< NotaFinal.length) {
			System.out.println("\n Reprobados: "+ Reprobado);
	}
}if(NotaFinal[i]<=69) {
		Regular++;
		System.out.print("=");
		if(i< NotaFinal.length) {
			System.out.println("\n Regular: "+ Regular);
	}
}if(NotaFinal[i]<=79) {
		Bueno++;
		System.out.print("=");
		if(i< NotaFinal.length) {
			System.out.println("Bueno: "+ Bueno);
		}
	}if(NotaFinal[i]<=89) {
		MuyBueno++;
		System.out.print("=");
		if(i< NotaFinal.length) {
			System.out.println("Muy bueno: "+ MuyBueno);
		}
	}else {
		Excelente++;
		System.out.print("=");
		if(i< NotaFinal.length) {
			System.out.println("Excelente: "+ Excelente);
		}	
			}
		}
	}


}
